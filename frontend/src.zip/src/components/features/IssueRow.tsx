import type { IssueResponse } from "../../types/Issue";
import Badge from "../base/Badge";
import Button from "../base/Button";

interface IssueRowProps {
    issue: IssueResponse;
    onSelect: (issue: IssueResponse) => void;
    onEdit: (issue: IssueResponse) => void;
    onDelete: (id: string) => void;

}

export default function IssueRow({
    issue,
    onSelect,
    onEdit,
    onDelete,
}: IssueRowProps) {
    return (
        <div
            className="issue-row"
            onClick={() => onSelect(issue)}
        >
            <div className="issue-info">
                <h3>{issue.title}</h3>
                <p>{issue.description}</p>
            </div>

            <div className="issue-meta">
                <Badge variant={issue.status}>
                    {issue.status}
                </Badge>
                <Badge variant={issue.priority}>
                    {issue.priority}
                </Badge>          
            </div>

            <div className="issue-actions">
                <Button
                    onClick={(e) => {
                        e.stopPropagation();
                        onEdit(issue);
                    }}
                >
                    Edit
                </Button>
                <Button
                    variant="danger"
                    onClick={(e) => {
                        e.stopPropagation();
                        onDelete(issue.id);
                    }}
                >
                    Delete
                </Button>
            </div>
        </div>
    );
}